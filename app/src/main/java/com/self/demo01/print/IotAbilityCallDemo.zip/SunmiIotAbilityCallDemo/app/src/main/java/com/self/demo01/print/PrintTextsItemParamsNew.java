package com.self.demo01.print;

public class PrintTextsItemParamsNew extends PrintTextParamsNew {
    public int weight = 1;
}
