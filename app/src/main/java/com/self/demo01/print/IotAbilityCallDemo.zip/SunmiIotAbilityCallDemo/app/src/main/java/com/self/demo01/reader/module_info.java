package com.self.demo01.reader;

public class module_info {
}
