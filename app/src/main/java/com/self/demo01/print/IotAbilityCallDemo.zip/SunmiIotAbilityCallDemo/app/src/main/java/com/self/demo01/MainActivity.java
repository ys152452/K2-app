package com.self.demo01;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.executor.ArchTaskExecutor;

import com.self.demo01.print.CommandRequest;
import com.self.demo01.print.PrintUtil;
import com.self.demo01.utils.LogUtil;
import com.sunmi.reader.usbhid.SunmiReader;
import com.sunmi.thingservice.sdk.IResponseCallback;
import com.sunmi.thingservice.sdk.IServiceEventListener;
import com.sunmi.thingservice.sdk.ThingSDK;
import com.sunmi.thingservice.sdk.ThingService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    public static SunmiReader sunmireader = new SunmiReader();
    public static MainActivity app;
    private static final String TAG = "MyActivity";
    TextView tv_print,tv_scan,tv_print_txt,tv_print_pic,tv_print_line,tv_print_qrcode,tv_print_barcode,tv_scan_start,tv_scan_stop,tv_scan_result,tv_result;
    LinearLayout ll_print,ll_scan;
    TextView tvPrintDemo;
    boolean scanTag = true;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        app = this;
        setContentView(R.layout.activity_main);
        initView();
        doRegisterEvent();
    }

    private class MyWebViewClient extends WebViewClient{
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            final Uri uri = Uri.parse(url);
            return true;
        }

        @TargetApi(Build.VERSION_CODES.N)
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            view.loadUrl(request.getUrl().toString());
            return true;
        }
    }
    private void initView() {
        WebView webView = (WebView) findViewById(R.id.web_view);
        String url = "file:///android_asset/index.html";
        WebSettings webSettings = webView.getSettings();
        //可以访问https
        webSettings.setBlockNetworkImage(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        //开启JavaScript
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        //设置可以访问文件
        webSettings.setAllowFileAccess(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); // 不加载缓存内容
        webView.addJavascriptInterface(new WebAppInterface(this),"K2");

        webView.loadUrl(url);
        webView.loadUrl("javascript:recScanResult('" + 1 + "')");
        webView.setWebViewClient(new MyWebViewClient(){
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();// 接受所有网站的证书
                super.onReceivedSslError(view, handler, error);
            }
        });
    }
    CommandRequest commandRequest;
    public class WebAppInterface {
        Context mContext;
        private int ret;
        private String texttemp;

        WebAppInterface(Context c) {
            mContext = c;
        }
        @JavascriptInterface
        public void doPrint(String b64) {
//            Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
              print(PrintUtil.getPicRequest(b64));
        }
        @JavascriptInterface
        public void doScan() {
            commandRequest = new CommandRequest();
            commandRequest.command = "start_scan";
            printScan(commandRequest);
        }
        @JavascriptInterface
        public void doRead() {
            UsbManager usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
            HashMap<String, UsbDevice> usbDeviceList = usbManager.getDeviceList();
            for (UsbDevice usbDevice : usbDeviceList.values()) {
                int vid = usbDevice.getVendorId();
                int pid = usbDevice.getProductId();

                // 打印 VID 和 PID
                Log.d("USB Info", "Vendor ID (VID): " + vid);
                Log.d("USB Info", "Product ID (PID): " + pid);
            }
            if (!sunmireader.isOpen()) {
                ret = sunmireader.open(getApplicationContext());
                Log.d("sunmireader Info", "ret: " + ret);
                texttemp = "sunmireader Info ret: " + ret;
                Toast.makeText(mContext, texttemp, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void doRegisterEvent() {
        if (Application.scannerList == null || Application.scannerList.size() == 0) {
            Toast.makeText(this, "请先获取摄像头", Toast.LENGTH_SHORT).show();
            return;
        }else {
            try {
                ThingSDK.getInstance().registerServiceEvent(Application.scannerList.get(0).deviceId, Application.scannerList.get(0).serviceId, iServiceEventListener);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }
    }

    private synchronized void print(CommandRequest request) {
        if (Application.printerList == null || Application.printerList.size() == 0) {
            Toast.makeText(this, "请先获取打印机", Toast.LENGTH_SHORT).show();
            return;
        } else {
            LogUtil.e(TAG, "sass send------:" + PrintUtil.gson.toJson(Application.printerList.get(0)));
        }
        String callUuid = null;
        ThingService service = Application.printerList.get(0);

        final long time = SystemClock.elapsedRealtime();
        LogUtil.e(TAG, "sass send:" + SystemClock.elapsedRealtime());
        try {
            callUuid = ThingSDK.getInstance().execute(service, ThingSDK.ACTION_TYPE_COMMAND, ThingSDK.ACTION_EXECUTE, PrintUtil.gson.toJson(request), new IResponseCallback.Stub() {
                @Override
                public void response(String uuid, Map data) throws RemoteException {
                    LogUtil.e(TAG, "sass receive:" + SystemClock.elapsedRealtime());
                    LogUtil.e(TAG, uuid + ";" + time);
                    long t1 = SystemClock.elapsedRealtime();
                    LogUtil.e(TAG, time + ";" + t1 + "  ; " + (t1 - time));
                    if (data != null) {
                        StringBuilder builder = new StringBuilder("print-->");
                        for (Object s : data.keySet()) {
                            builder.append(s + "  :  " + data.get(s) + "；");
                        }
                        LogUtil.e(TAG, "res:" + builder.toString() + "    ;" + t1);
                    }
                }
            });
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        LogUtil.e(TAG, " print call :" + callUuid + ";" + PrintUtil.gson.toJson(request));

    }

    private synchronized void printScan(CommandRequest request) {
        Map<String, String> map = new HashMap<>();
//        map.put("command", "start_scan");

        if (Application.scannerList == null || Application.scannerList.size() == 0) {
            Toast.makeText(this, "请先获取摄像头", Toast.LENGTH_SHORT).show();
            return;
        }
        LogUtil.e(TAG+" SCAN 4444444", "====================:" + request.command);
        String callUuid = null;
        final long time = SystemClock.elapsedRealtime();
        LogUtil.e(TAG +" SCAN 0", "sass send:" + SystemClock.elapsedRealtime());
        try {
            callUuid = ThingSDK.getInstance().executeCommand(Application.scannerList.get(0), PrintUtil.gson.toJson(map), new IResponseCallback.Stub() {
                @Override
                public void response(String uuid, Map data) throws RemoteException {
                    LogUtil.e(TAG+" SCAN 1", "sass receive:" + SystemClock.elapsedRealtime());
                    LogUtil.e(TAG+" SCAN 2", uuid + ";" + time);
                    long t1 = SystemClock.elapsedRealtime();
                    LogUtil.e(TAG+" SCAN 3", time + ";" + t1 + "  ; " + (t1 - time));
                    if (data != null) {
                        StringBuilder builder = new StringBuilder("SCAN-->");
                        for (Object s : data.keySet()) {
                            builder.append(s + "  :  " + data.get(s) + "；");
                        }
                        LogUtil.e(TAG+" SCAN 4", "res:" + builder.toString() + "    ;" + t1);
                    }
                }
            });
        } catch (RemoteException e) {
            LogUtil.e(TAG+" SCAN 555");
            e.printStackTrace();
            LogUtil.e(TAG+" SCAN 666");
        }
        LogUtil.e(TAG+" SCAN ", " SCAN call 123123123 :" + callUuid + ";" + PrintUtil.gson.toJson(request));

    }
    private synchronized void printRead(CommandRequest request) {
        Map<String, String> map = new HashMap<>();
//        map.put("command", "start_scan");

        if (Application.msrList == null || Application.msrList.size() == 0) {
            Toast.makeText(this, "请先获取摄像头", Toast.LENGTH_SHORT).show();
            return;
        }
        LogUtil.e(TAG+" SCAN 4444444", "====================:" + request.command);
        String callUuid = null;
        final long time = SystemClock.elapsedRealtime();
        LogUtil.e(TAG +" SCAN 0", "sass send:" + SystemClock.elapsedRealtime());
        try {
            callUuid = ThingSDK.getInstance().executeCommand(Application.msrList.get(0), PrintUtil.gson.toJson(map), new IResponseCallback.Stub() {
                @Override
                public void response(String uuid, Map data) throws RemoteException {
                    LogUtil.e(TAG+" SCAN 1", "sass receive:" + SystemClock.elapsedRealtime());
                    LogUtil.e(TAG+" SCAN 2", uuid + ";" + time);
                    long t1 = SystemClock.elapsedRealtime();
                    LogUtil.e(TAG+" SCAN 3", time + ";" + t1 + "  ; " + (t1 - time));
                    if (data != null) {
                        StringBuilder builder = new StringBuilder("SCAN-->");
                        for (Object s : data.keySet()) {
                            builder.append(s + "  :  " + data.get(s) + "；");
                        }
                        LogUtil.e(TAG+" SCAN 4", "res:" + builder.toString() + "    ;" + t1);
                    }
                }
            });
        } catch (RemoteException e) {
            LogUtil.e(TAG+" SCAN 555");
            e.printStackTrace();
            LogUtil.e(TAG+" SCAN 666");
        }
        LogUtil.e(TAG+" SCAN ", " SCAN call 123123123 :" + callUuid + ";" + PrintUtil.gson.toJson(request));

    }

    private class Task extends TimerTask {
        @Override
        public void run() {
            scanTag = false;
        }
    }

    IServiceEventListener iServiceEventListener = new IServiceEventListener.Stub() {
        @Override
        public void onEvent(String deviceId, String serviceId, String eventParam) throws RemoteException {
            LogUtil.e("ricardo2   ", " registerEvent call :" + deviceId + "  " + serviceId + "  " + eventParam);
            WebView webView = (WebView) findViewById(R.id.web_view);
            runOnUiThread(() -> {
                webView.loadUrl("javascript:recScanResult('" + eventParam + "')");
            });
            iServiceEventListener = null;
        }
    };
    IServiceEventListener iServiceEventListener2 = new IServiceEventListener.Stub() {
        @Override
        public void onEvent(String deviceId, String serviceId, String eventParam) throws RemoteException {
            LogUtil.e("ricardo2   ", " registerEvent call :" + deviceId + "  " + serviceId + "  " + eventParam);
//            WebView webView = (WebView) findViewById(R.id.web_view);
//            runOnUiThread(() -> {
//                webView.loadUrl("javascript:recScanResult('" + eventParam + "')");
//            });
            iServiceEventListener2 = null;
        }
    };

}
