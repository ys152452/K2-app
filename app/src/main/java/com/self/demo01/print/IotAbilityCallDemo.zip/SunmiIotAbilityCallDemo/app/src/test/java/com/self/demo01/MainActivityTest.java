package com.self.demo01;

import android.util.Log;

import com.self.demo01.utils.LogUtil;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase {

    public void testOnCreate() {
        Log.i(toString().valueOf(1), toString().valueOf(1));
    }
}