package com.self.demo01.print;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class PropertyGet {
    @SerializedName("property_list")
    public List<String> propertyList;
}
