package com.self.demo01.reader;

import javax.smartcardio.*;
public class NFCUtil {
    public static void main(String[] args) {
        try {
            // 获取NFC读卡器
            TerminalFactory terminalFactory = TerminalFactory.getDefault();
            CardTerminals cardTerminals = terminalFactory.terminals();
            CardTerminal cardTerminal = cardTerminals.list().get(0);

            // 连接NFC卡
            Card card = cardTerminal.connect("*");

            // 获取卡片通道
            CardChannel cardChannel = card.getBasicChannel();

            // 构造读取APDU命令
            byte[] readCommand = new byte[]{(byte) 0xFF, (byte) 0xB0, (byte) 0x00, (byte) 0x04, (byte) 0x10};

            // 发送APDU命令进行读取操作
            byte[] response = cardChannel.transmit(new CommandAPDU(readCommand));

            // 解析响应数据
            byte[] data = response.clone();

            // 关闭连接
            card.disconnect(false);

            System.out.println("读取到的数据：" + new String(data));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}